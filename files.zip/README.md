# EventMind – AI-Powered Physical Event Companion

> Prompt Wars 3 Hackathon Submission · Vertical: **Physical Event Experience**

---

## What It Does

EventMind is a smart AI assistant that helps attendees navigate and get the most out of physical events like conferences, summits, and hackathons.

Attendees open the app, set their role (e.g. "ML engineer", "startup founder"), and ask anything:

- *"Recommend sessions for me"*
- *"What's happening right now?"*
- *"Where is the food?"*
- *"Help me plan my full day"*

The AI understands their context and gives specific, actionable answers — not generic ones.

---

## Chosen Vertical

**Physical Event Experience**

The challenge: physical events are information-dense and overwhelming. Attendees miss sessions relevant to them, don't know where things are, and can't easily plan their day. EventMind solves this with a context-aware AI assistant that knows everything about the event and adapts its answers to each attendee's role and interests.

---

## How It Works

### Architecture

```
User (Browser)
    │
    ▼
Flask Web App (Cloud Run)
    │
    ├── GET  /          → Renders the event UI (schedule, info, chat)
    ├── POST /chat      → Processes user message via Gemini API
    └── GET  /health    → Health check endpoint
    │
    ▼
Google Gemini API (gemini-2.0-flash)
```

### Key Logic

1. **Context Injection**: On the first message, the full event data (sessions, speakers, rooms, amenities) is injected into the system prompt so Gemini has complete knowledge of the event.

2. **User Profiling**: The attendee sets their role at the top of the chat. This gets passed with every request, so recommendations are always personalized.

3. **Conversation History**: All previous turns are sent with each request, enabling multi-turn conversations (e.g., follow-up questions, refinements).

4. **Smart Recommendations**: Gemini reasons over the attendee's profile + event data to suggest sessions that specifically match their background — with explanations for each choice.

### Google Services Used

| Service | How It's Used |
|---|---|
| **Gemini API** (gemini-2.0-flash) | Powers the AI assistant — understands context, recommends sessions, answers questions |
| **Google Maps Embed** | Shows the venue location directly in the app's Info tab |
| **Google Cloud Run** | Hosts and serves the application at scale |

---

## Assumptions Made

- Event data is pre-loaded in `app.py`. In production, this would come from a database or event management API.
- The app targets a single event. Multi-event support would require a database layer.
- Attendees have basic smartphone/browser access at the venue.
- Gemini API key is provided as an environment variable (`GEMINI_API_KEY`) — never hardcoded.

---

## Project Structure

```
eventmind/
├── app.py               # Flask backend + Gemini integration
├── templates/
│   └── index.html       # Full frontend (UI, chat, schedule, info)
├── requirements.txt     # Python dependencies
├── Dockerfile           # Container config for Cloud Run
├── .dockerignore
└── README.md
```

---

## Local Setup

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/eventmind.git
cd eventmind

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set your Gemini API key
export GEMINI_API_KEY="your_key_here"

# 4. Run locally
python app.py

# Visit http://localhost:8080
```

---

## Cloud Run Deployment

```bash
# 1. Set your project
gcloud config set project YOUR_PROJECT_ID

# 2. Build and deploy directly
gcloud run deploy eventmind \
  --source . \
  --platform managed \
  --region asia-south1 \
  --allow-unauthenticated \
  --set-env-vars GEMINI_API_KEY=your_key_here

# 3. Copy the deployed URL from the output
```

---

## Evaluation Criteria Coverage

| Criteria | How Addressed |
|---|---|
| **Code Quality** | Clean separation of backend/frontend, clear comments, single-responsibility functions |
| **Security** | API key via env var only, input validation, no secrets in code |
| **Efficiency** | Gemini Flash model (fast + cost-effective), conversation history managed on client |
| **Testing** | `/health` endpoint, error handling on all API calls, graceful error messages to user |
| **Accessibility** | Semantic HTML, sufficient color contrast, keyboard navigation (Enter to send) |
| **Google Services** | Gemini API for AI, Maps Embed for location, Cloud Run for hosting |
