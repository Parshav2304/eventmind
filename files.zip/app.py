import os
import json
from flask import Flask, render_template, request, jsonify
import google.generativeai as genai

app = Flask(__name__)

# Load Gemini API key from environment
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
genai.configure(api_key=GEMINI_API_KEY)

# ── Event Data ─────────────────────────────────────────────────────────────────
EVENT_DATA = {
    "name": "TechSummit 2026",
    "tagline": "Building the Future, Together",
    "date": "April 20–21, 2026",
    "venue": "GIFT City Convention Center, Gandhinagar, Gujarat, India",
    "map_query": "GIFT+City+Convention+Centre+Gandhinagar",
    "tracks": [
        {
            "name": "AI & Machine Learning",
            "color": "#4F46E5",
            "sessions": [
                {"time": "09:00 AM", "title": "Keynote: The Era of AI Agents",        "speaker": "Dr. Priya Sharma",  "room": "Hall A", "level": "All"},
                {"time": "10:30 AM", "title": "Building RAG Systems at Scale",         "speaker": "Rahul Mehta",      "room": "Hall A", "level": "Intermediate"},
                {"time": "02:00 PM", "title": "LLM Fine-Tuning Workshop",              "speaker": "Ananya Patel",     "room": "Lab 1",  "level": "Advanced"},
                {"time": "04:00 PM", "title": "Responsible AI: Real-World Guardrails", "speaker": "Siddharth Iyer",  "room": "Hall A", "level": "All"}
            ]
        },
        {
            "name": "Cloud & DevOps",
            "color": "#059669",
            "sessions": [
                {"time": "09:30 AM", "title": "Cloud Run: Production Best Practices",  "speaker": "Vikram Singh",    "room": "Hall B", "level": "Intermediate"},
                {"time": "11:00 AM", "title": "Kubernetes for Growing Startups",       "speaker": "Meera Joshi",     "room": "Hall B", "level": "Intermediate"},
                {"time": "01:30 PM", "title": "Infrastructure as Code with Terraform", "speaker": "Arjun Kumar",     "room": "Hall B", "level": "Advanced"},
                {"time": "03:30 PM", "title": "Cost Optimization on GCP",              "speaker": "Pooja Desai",     "room": "Lab 2",  "level": "All"}
            ]
        },
        {
            "name": "Web & Mobile",
            "color": "#D97706",
            "sessions": [
                {"time": "10:00 AM", "title": "React 19: What's New and Why It Matters", "speaker": "Sneha Gupta",  "room": "Hall C", "level": "Intermediate"},
                {"time": "12:00 PM", "title": "Flutter for Enterprise Apps",              "speaker": "Deepak Rao",   "room": "Hall C", "level": "Intermediate"},
                {"time": "02:30 PM", "title": "Web Performance: 0–100 in 60 Seconds",    "speaker": "Kavya Nair",   "room": "Hall C", "level": "All"},
                {"time": "04:30 PM", "title": "Offline-First PWA Patterns",               "speaker": "Amit Verma",   "room": "Lab 3",  "level": "Advanced"}
            ]
        }
    ],
    "amenities": {
        "food":    "Cafeteria on Level 2 (8 AM – 6 PM). Tea/coffee on every floor.",
        "wifi":    "Network: TechSummit2026 | Password: innovate@2026",
        "parking": "Basement P1 & P2 — free for badge holders. Show badge at entry.",
        "helpdesk":"Main Lobby, Ground Floor. Volunteers in orange T-shirts.",
        "emergency":"Security desk near Gate 1. First aid at Level 1, Room 104."
    }
}

# ── System Prompt ───────────────────────────────────────────────────────────────
SYSTEM_PROMPT = """You are EventMind, a smart AI assistant for {event_name}.
You help attendees have the best possible event experience.

EVENT DATA:
{event_json}

YOUR JOB:
1. Answer questions about sessions, speakers, timing, and rooms clearly and specifically.
2. Recommend sessions based on the attendee's role and interests — explain WHY each fits them.
3. Help with logistics: food, WiFi, parking, help desk, emergency.
4. Help attendees plan their day efficiently (avoid scheduling conflicts).
5. Suggest networking opportunities between sessions.

RULES:
- Be specific. Never give vague answers.
- If recommending sessions, ask about their role/interests first if not provided.
- Always mention room + time when discussing sessions.
- Keep responses concise but complete. Use bullet points for lists.
- If you truly don't know something, direct them to the Help Desk at the Main Lobby.
- Never make up session details not in the event data.

ATTENDEE PROFILE: {profile}
""".format(
    event_name=EVENT_DATA["name"],
    event_json=json.dumps(EVENT_DATA, indent=2),
    profile="{profile}"  # filled dynamically per request
)


# ── Routes ──────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html", event=EVENT_DATA)


@app.route("/chat", methods=["POST"])
def chat():
    """Handle a chat message. Accepts full conversation history from the client."""
    body = request.get_json(force=True)
    user_message = body.get("message", "").strip()
    history      = body.get("history", [])   # [{role, text}, ...]
    profile      = body.get("profile", "Not provided")

    if not user_message:
        return jsonify({"error": "Empty message"}), 400

    if not GEMINI_API_KEY:
        return jsonify({"error": "GEMINI_API_KEY not configured on the server."}), 500

    try:
        model = genai.GenerativeModel("gemini-2.0-flash")

        # Build Gemini history from previous turns
        gemini_history = []
        for turn in history:
            role    = "user"  if turn["role"] == "user" else "model"
            gemini_history.append({"role": role, "parts": [turn["text"]]})

        chat_session = model.start_chat(history=gemini_history)

        # Inject system context into very first message only
        if not history:
            full_msg = (
                f"[SYSTEM]\n{SYSTEM_PROMPT.format(profile=profile)}\n[/SYSTEM]\n\n"
                f"{user_message}"
            )
        else:
            full_msg = user_message

        response = chat_session.send_message(full_msg)
        return jsonify({"response": response.text})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/health")
def health():
    return jsonify({"status": "ok", "event": EVENT_DATA["name"]})


# ── Entry point ─────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port, debug=False)
